/*
 * syscall_trace.c – ptrace-based syscall counting and timing
 *
 * OS concepts demonstrated:
 *   fork(), execvp(), ptrace(PTRACE_TRACEME / PTRACE_SYSCALL /
 *   PTRACE_GETREGS / PTRACE_SETOPTIONS), SIGTRAP, SIGSTOP,
 *   waitpid(), clock_gettime(CLOCK_MONOTONIC), setpgid(), kill()
 *
 * Architecture: x86_64 only (PTRACE_GETREGS uses struct user_regs_struct).
 * On other arches the function returns -1 with an informative error message.
 *
 * WSL note: ptrace may be blocked by the WSL seccomp profile or by the
 * /proc/sys/kernel/yama/ptrace_scope setting.  If you see EPERM, run:
 *   echo 0 | sudo tee /proc/sys/kernel/yama/ptrace_scope
 * or add the capability to your WSL instance.
 */
#include "syscall_trace.h"
#include "profiler.h"

#include <sys/ptrace.h>
#include <sys/user.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
#include <time.h>
#include <unistd.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Maximum syscall number we track (Linux x86_64 currently < 450) */
#define MAX_SYSCALL 512

/* -------------------------------------------------------------------------
 * Helpers
 * ------------------------------------------------------------------------- */

static double elapsed_ms(struct timespec a, struct timespec b)
{
    return (b.tv_sec - a.tv_sec) * 1000.0
         + (b.tv_nsec - a.tv_nsec) / 1000000.0;
}

/**
 * sysname – map a syscall number to a human-readable name.
 * Only the most-commonly seen syscalls are listed; others become "other".
 */
static const char *sysname(long n)
{
#if defined(__x86_64__)
    switch (n) {
    case   0: return "read";
    case   1: return "write";
    case   2: return "open";
    case   3: return "close";
    case   4: return "stat";
    case   5: return "fstat";
    case   6: return "lstat";
    case   7: return "poll";
    case   8: return "lseek";
    case   9: return "mmap";
    case  10: return "mprotect";
    case  11: return "munmap";
    case  12: return "brk";
    case  13: return "rt_sigaction";
    case  14: return "rt_sigprocmask";
    case  16: return "ioctl";
    case  17: return "pread64";
    case  18: return "pwrite64";
    case  19: return "readv";
    case  20: return "writev";
    case  21: return "access";
    case  22: return "pipe";
    case  23: return "select";
    case  24: return "sched_yield";
    case  32: return "dup";
    case  33: return "dup2";
    case  35: return "nanosleep";
    case  39: return "getpid";
    case  40: return "sendfile";
    case  41: return "socket";
    case  42: return "connect";
    case  45: return "recvfrom";
    case  56: return "clone";
    case  57: return "fork";
    case  59: return "execve";
    case  60: return "exit";
    case  61: return "wait4";
    case  62: return "kill";
    case  63: return "uname";
    case  72: return "fcntl";
    case  79: return "getcwd";
    case  83: return "mkdir";
    case  85: return "creat";
    case  87: return "unlink";
    case  89: return "readlink";
    case  99: return "statfs";
    case 102: return "getuid";
    case 104: return "getgid";
    case 107: return "geteuid";
    case 108: return "getegid";
    case 110: return "getppid";
    case 111: return "getpgrp";
    case 158: return "arch_prctl";
    case 186: return "gettid";
    case 202: return "futex";
    case 217: return "getdents64";
    case 228: return "clock_gettime";
    case 231: return "exit_group";
    case 257: return "openat";
    case 262: return "newfstatat";
    case 302: return "prlimit64";
    case 318: return "getrandom";
    case 334: return "rseq";
    default:  return "other";
    }
#else
    (void)n;
    return "unknown";
#endif
}

/* -------------------------------------------------------------------------
 * Public API
 * ------------------------------------------------------------------------- */

int syscall_trace_run(const char *command, const char *args_text,
                      int timeout_ms,
                      char *json_out, size_t json_capacity)
{
#if !defined(__x86_64__)
    (void)command; (void)args_text; (void)timeout_ms;
    snprintf(json_out, json_capacity,
             "{\"error\":\"syscall tracing requires x86_64 Linux\"}");
    return -1;
#else
    if (!command_is_allowed(command)
        || timeout_ms < 100 || timeout_ms > 60000)
    {
        snprintf(json_out, json_capacity,
                 "{\"error\":\"invalid command or timeout\"}");
        return -1;
    }

    /* Build argv */
    char *argv[68];
    memset(argv, 0, sizeof(argv));
    argv[0] = strdup(command);
    if (!argv[0]) return -1;

    char *copy = strdup(args_text ? args_text : "");
    if (!copy) { free(argv[0]); return -1; }

    int ac = 0;
    char *save = NULL;
    for (char *tok = strtok_r(copy, " \t\r\n", &save);
         tok && ac < 63;
         tok = strtok_r(NULL, " \t\r\n", &save))
    {
        if (strlen(tok) > 256
            || strchr(tok, ';') || strchr(tok, '|')
            || strchr(tok, '`') || strstr(tok, "$(")
            || strchr(tok, '&') || strchr(tok, '>')
            || strchr(tok, '<'))
        {
            free(copy);
            for (int i = 0; argv[i]; i++) free(argv[i]);
            snprintf(json_out, json_capacity,
                     "{\"error\":\"shell metacharacter in argument\"}");
            return -1;
        }
        argv[ac + 1] = strdup(tok);
        if (!argv[ac + 1]) { free(copy); return -1; }
        ac++;
    }
    free(copy);
    argv[ac + 1] = NULL;

    /* Fork child */
    pid_t pid = fork();
    if (pid < 0) {
        for (int i = 0; argv[i]; i++) free(argv[i]);
        snprintf(json_out, json_capacity, "{\"error\":\"fork failed\"}");
        return -1;
    }

    if (pid == 0) {
        /* ---- Tracee child ---------------------------------------- */
        setpgid(0, 0);

        /* Redirect output to /dev/null – we measure, not display */
        int dn = open("/dev/null", O_WRONLY);
        if (dn >= 0) {
            dup2(dn, STDOUT_FILENO);
            dup2(dn, STDERR_FILENO);
            close(dn);
        }

        /* Signal to the kernel that this process wants to be traced */
        if (ptrace(PTRACE_TRACEME, 0, NULL, NULL) < 0) _exit(125);

        execvp(command, argv);
        _exit(127);
    }

    /* ---- Tracer parent ------------------------------------------- */
    for (int i = 0; argv[i]; i++) free(argv[i]);
    setpgid(pid, pid);

    /* Tracking tables */
    unsigned long long counts[MAX_SYSCALL];
    double             times[MAX_SYSCALL];
    memset(counts, 0, sizeof(counts));
    memset(times,  0, sizeof(times));

    unsigned long long total    = 0;
    int                entering = 1;
    long               current  = -1;
    int                timed_out = 0;
    int                deliver_sig = 0;

    struct timespec start, now, entry_time;
    clock_gettime(CLOCK_MONOTONIC, &start);

    /* Wait for the initial SIGSTOP triggered by PTRACE_TRACEME */
    int wstatus = 0;
    if (waitpid(pid, &wstatus, 0) < 0) {
        kill(-pid, SIGKILL);
        snprintf(json_out, json_capacity,
                 "{\"error\":\"waitpid failed after fork\"}");
        return -1;
    }
    if (!WIFSTOPPED(wstatus)) {
        snprintf(json_out, json_capacity,
                 "{\"error\":\"trace setup failed – ptrace may be restricted "
                 "(check /proc/sys/kernel/yama/ptrace_scope)\"}");
        return -1;
    }

    /* Tell ptrace to tag syscall-entry/exit stops with SIGTRAP|0x80 */
    ptrace(PTRACE_SETOPTIONS, pid, NULL,
           (void *)(long)(PTRACE_O_TRACESYSGOOD));

    /* ---- Main trace loop ----------------------------------------- */
    for (;;) {
        clock_gettime(CLOCK_MONOTONIC, &now);
        if (elapsed_ms(start, now) > timeout_ms) {
            timed_out = 1;
            kill(-pid, SIGKILL);
        }

        if (ptrace(PTRACE_SYSCALL, pid, NULL,
                   (void *)(long)deliver_sig) < 0
            && errno != ESRCH)
        {
            kill(-pid, SIGKILL);
        }
        deliver_sig = 0;

        if (waitpid(pid, &wstatus, 0) < 0) {
            if (errno == EINTR) continue;
            break;
        }

        if (WIFEXITED(wstatus) || WIFSIGNALED(wstatus)) break;
        if (!WIFSTOPPED(wstatus)) continue;

        int sig = WSTOPSIG(wstatus);

        if (sig == (SIGTRAP | 0x80)) {
            /* Syscall-entry or syscall-exit stop */
            struct user_regs_struct regs;
            if (ptrace(PTRACE_GETREGS, pid, NULL, &regs) == 0) {
                if (entering) {
                    current = (long)regs.orig_rax;
                    clock_gettime(CLOCK_MONOTONIC, &entry_time);
                } else if (current >= 0 && current < MAX_SYSCALL) {
                    clock_gettime(CLOCK_MONOTONIC, &now);
                    counts[current]++;
                    times[current] += elapsed_ms(entry_time, now);
                    total++;
                }
            }
            entering = !entering;
        } else if (sig == SIGTRAP || sig == SIGSTOP) {
            /* ptrace event – do not redeliver */
        } else {
            /* Forward genuine signals to the tracee */
            deliver_sig = sig;
        }
    }

    /* Ensure tracee is fully reaped */
    if (!WIFEXITED(wstatus) && !WIFSIGNALED(wstatus))
        waitpid(pid, &wstatus, 0);

    /* ---- Build JSON output --------------------------------------- */

    /* Find top-10 syscalls by invocation count */
    long top[10];
    for (int i = 0; i < 10; i++) top[i] = -1;

    for (int k = 0; k < 10; k++) {
        unsigned long long best = 0;
        for (int n = 0; n < MAX_SYSCALL; n++) {
            int already = 0;
            for (int j = 0; j < k; j++) if (top[j] == n) { already = 1; break; }
            if (!already && counts[n] > best) { best = counts[n]; top[k] = n; }
        }
    }

    size_t used = 0;
    int n = snprintf(json_out, json_capacity,
                     "{\"total_syscalls\":%llu,\"timed_out\":%s,"
                     "\"exit_code\":%d,\"summary\":[",
                     total,
                     timed_out ? "true" : "false",
                     WIFEXITED(wstatus) ? WEXITSTATUS(wstatus) : -1);
    if (n < 0) return -1;
    used = (size_t)n;

    int first = 1;
    for (int i = 0; i < 10; i++) {
        long sc = top[i];
        if (sc < 0 || counts[sc] == 0) continue;
        n = snprintf(json_out + used, json_capacity - used,
                     "%s{\"number\":%ld,\"name\":\"%s\","
                     "\"count\":%llu,"
                     "\"total_elapsed_ms\":%.4f,"
                     "\"average_elapsed_ms\":%.6f}",
                     first ? "" : ",",
                     sc, sysname(sc), counts[sc],
                     times[sc],
                     times[sc] / (double)counts[sc]);
        if (n < 0 || (size_t)n >= json_capacity - used) break;
        used += (size_t)n;
        first = 0;
    }

    if (used + 3 < json_capacity)
        snprintf(json_out + used, json_capacity - used, "]}");

    return 0;
#endif
}
