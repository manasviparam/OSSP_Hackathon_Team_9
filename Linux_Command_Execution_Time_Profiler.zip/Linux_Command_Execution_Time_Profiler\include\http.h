#ifndef HTTP_H
#define HTTP_H

#include <stddef.h>

/** Maximum request body length accepted by the server. */
#define HTTP_MAX_BODY 65536

/**
 * http_request_t – parsed HTTP/1.1 request (headers stripped).
 */
typedef struct {
    char method[16];           /* "GET", "POST", …             */
    char path[512];            /* request path + query string  */
    char body[HTTP_MAX_BODY];  /* raw request body             */
    size_t body_len;           /* actual body length in bytes  */
} http_request_t;

/**
 * http_read_request – read one HTTP request from *fd* into *req*.
 * @return 0 on success, -1 on protocol error or EOF
 */
int http_read_request(int fd, http_request_t *req);

/**
 * http_send_response – write a complete HTTP response.
 */
void http_send_response(int fd, int status, const char *reason,
                        const char *type, const char *body, size_t len);

/**
 * http_send_json – convenience wrapper: sends JSON with correct headers.
 */
void http_send_json(int fd, int status, const char *body);

/**
 * http_send_file – serve a file from disk with auto-detected content-type.
 * Path traversal ("..") is rejected with 400.
 */
void http_send_file(int fd, const char *path);

#endif /* HTTP_H */
