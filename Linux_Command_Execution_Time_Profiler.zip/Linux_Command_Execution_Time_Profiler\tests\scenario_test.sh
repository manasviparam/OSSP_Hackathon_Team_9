#!/usr/bin/env bash
# scenario_test.sh – integration/scenario tests for the profiler server
# Tests command I/O capture, file reading, sorting, exit codes,
# timeouts, allowlist rejection, multiple sequential runs, and
# the history/stats persistence endpoints.
set -euo pipefail

PORT=18082
BINARY=./profiler_server

echo "=== Scenario Tests ==="

# ── Pre-flight ──────────────────────────────────────────────
if [ ! -x "$BINARY" ]; then
    echo "ERROR: $BINARY not found. Run 'make' first."
    exit 1
fi

mkdir -p db
"$BINARY" "$PORT" > /tmp/profiler-scenarios.log 2>&1 &
SERVER_PID=$!
TMPFILE=/tmp/profiler-scenario-input.txt
trap 'kill "$SERVER_PID" 2>/dev/null || true; rm -f "$TMPFILE"' EXIT
sleep 1

BASE="http://127.0.0.1:$PORT"

pass() { echo "PASS: $1"; }
fail() { echo "FAIL: $1"; exit 1; }

# ── Prepare test data ────────────────────────────────────────
printf 'pear\napple\nbanana\norange\nkiwi\n' > "$TMPFILE"

# ── Scenario 1: cat reads file contents ─────────────────────
R=$(curl -fsS -X POST "$BASE/api/run" \
    -H 'Content-Type: application/json' \
    -d "{\"command\":\"cat\",\"args\":\"$TMPFILE\",\"timeout_ms\":3000}")
echo "$R" | grep -q 'banana' || fail "cat did not capture file contents"
echo "$R" | grep -q '"status":"completed"' || fail "cat status not completed"
pass "Scenario 1: cat reads file"

# ── Scenario 2: sort processes file ─────────────────────────
R=$(curl -fsS -X POST "$BASE/api/run" \
    -H 'Content-Type: application/json' \
    -d "{\"command\":\"sort\",\"args\":\"$TMPFILE\",\"timeout_ms\":3000}")
echo "$R" | grep -q 'apple'  || fail "sort output missing 'apple'"
echo "$R" | grep -q '"status":"completed"' || fail "sort status not completed"
pass "Scenario 2: sort alphabetically"

# ── Scenario 3: wc counts lines ─────────────────────────────
R=$(curl -fsS -X POST "$BASE/api/run" \
    -H 'Content-Type: application/json' \
    -d "{\"command\":\"wc\",\"args\":\"-l $TMPFILE\",\"timeout_ms\":3000}")
echo "$R" | grep -q '"status":"completed"' || fail "wc status not completed"
pass "Scenario 3: wc -l"

# ── Scenario 4: grep nonexistent → nonzero exit → failed ────
R=$(curl -fsS -X POST "$BASE/api/run" \
    -H 'Content-Type: application/json' \
    -d "{\"command\":\"grep\",\"args\":\"notfound $TMPFILE\",\"timeout_ms\":3000}")
echo "$R" | grep -q '"status":"failed"' || fail "grep no-match should be 'failed'"
echo "$R" | grep -q '"exit_code":1'     || fail "grep exit code should be 1"
pass "Scenario 4: grep nonexistent (nonzero exit)"

# ── Scenario 5: echo captures stdout ────────────────────────
R=$(curl -fsS -X POST "$BASE/api/run" \
    -H 'Content-Type: application/json' \
    -d '{"command":"echo","args":"hello scenario test","timeout_ms":3000}')
echo "$R" | grep -q 'hello scenario test' || fail "echo stdout not in response"
echo "$R" | grep -q '"exit_code":0'       || fail "echo exit code should be 0"
pass "Scenario 5: echo stdout capture"

# ── Scenario 6: timeout enforcement ─────────────────────────
R=$(curl -fsS -X POST "$BASE/api/run" \
    -H 'Content-Type: application/json' \
    -d '{"command":"sleep","args":"5","timeout_ms":300}')
echo "$R" | grep -q '"status":"timed_out"' || fail "sleep should be timed_out"
echo "$R" | grep -q '"timed_out":true'     || fail "timed_out field should be true"
pass "Scenario 6: timeout kills sleep"

# ── Scenario 7: allowlist rejects bash ──────────────────────
CODE=$(curl -s -o /tmp/s-denied.json -w '%{http_code}' \
    -X POST "$BASE/api/run" \
    -H 'Content-Type: application/json' \
    -d '{"command":"bash","args":"-c whoami","timeout_ms":1000}')
[ "$CODE" = "403" ] || fail "bash should be rejected (got $CODE)"
pass "Scenario 7: allowlist rejects bash"

# ── Scenario 8: allowlist rejects shell metachar in args ────
CODE=$(curl -s -o /tmp/s-meta.json -w '%{http_code}' \
    -X POST "$BASE/api/run" \
    -H 'Content-Type: application/json' \
    -d '{"command":"echo","args":"hello; id","timeout_ms":1000}')
# Should be 400 (invalid arguments) not 403 (not allowlisted)
[ "$CODE" = "400" ] || fail "semicolon in args should cause 400 (got $CODE)"
pass "Scenario 8: shell metachar rejected in args"

# ── Scenario 9: history contains recent runs ─────────────────
HIST=$(curl -fsS "$BASE/api/history")
echo "$HIST" | grep -q '"command":"echo"'  || fail "echo not in history"
echo "$HIST" | grep -q '"command":"sleep"' || fail "sleep not in history"
pass "Scenario 9: history persists runs"

# ── Scenario 10: stats endpoint has data ─────────────────────
STATS=$(curl -fsS "$BASE/api/stats")
echo "$STATS" | grep -q '"command"' || fail "stats has no command field"
echo "$STATS" | grep -q '"runs"'    || fail "stats has no runs field"
pass "Scenario 10: stats endpoint"

# ── Scenario 11: uname -a succeeds ───────────────────────────
R=$(curl -fsS -X POST "$BASE/api/run" \
    -H 'Content-Type: application/json' \
    -d '{"command":"uname","args":"-a","timeout_ms":3000}')
echo "$R" | grep -qi 'linux' || fail "uname -a should mention Linux"
pass "Scenario 11: uname -a"

# ── Scenario 12: sequential runs accumulate in history ───────
for i in 1 2 3; do
    curl -fsS -X POST "$BASE/api/run" \
        -H 'Content-Type: application/json' \
        -d "{\"command\":\"echo\",\"args\":\"run-$i\",\"timeout_ms\":3000}" \
        > /dev/null
done
HIST2=$(curl -fsS "$BASE/api/history")
COUNT=$(echo "$HIST2" | grep -o '"command":"echo"' | wc -l)
[ "$COUNT" -ge 3 ] || fail "expected ≥3 echo runs in history, got $COUNT"
pass "Scenario 12: sequential runs persist"

echo ""
echo "=== All scenario tests passed. ==="
