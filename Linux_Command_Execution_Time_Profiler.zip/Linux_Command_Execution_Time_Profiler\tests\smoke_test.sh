#!/usr/bin/env bash
# smoke_test.sh – basic functional tests for the profiler server
# Runs a temporary server instance, fires API calls, validates responses.
set -euo pipefail

PORT=18080
BINARY=./profiler_server

echo "=== Smoke Tests ==="

# ── Build check ──────────────────────────────────────────────
if [ ! -x "$BINARY" ]; then
    echo "ERROR: $BINARY not found. Run 'make' first."
    exit 1
fi

# ── Start server ─────────────────────────────────────────────
mkdir -p db
"$BINARY" "$PORT" > /tmp/profiler-smoke.log 2>&1 &
SERVER_PID=$!
trap 'kill "$SERVER_PID" 2>/dev/null || true; echo "Server stopped."' EXIT
sleep 1

# Verify the server started
if ! kill -0 "$SERVER_PID" 2>/dev/null; then
    echo "FAIL: server did not start"
    cat /tmp/profiler-smoke.log
    exit 1
fi
echo "PASS: server started (PID $SERVER_PID)"

BASE="http://127.0.0.1:$PORT"

# ── Helper ───────────────────────────────────────────────────
pass() { echo "PASS: $1"; }
fail() { echo "FAIL: $1"; exit 1; }

check() {
    local desc="$1"
    local result="$2"
    if [ -z "$result" ]; then fail "$desc (empty response)"; fi
    echo "PASS: $desc"
}

# ── 1. Allowlist ─────────────────────────────────────────────
AL=$(curl -fsS "$BASE/api/allowlist")
echo "$AL" | grep -q '"sleep"' || fail "allowlist missing 'sleep'"
echo "$AL" | grep -q '"echo"'  || fail "allowlist missing 'echo'"
pass "allowlist endpoint"

# ── 2. Run echo ──────────────────────────────────────────────
RUN=$(curl -fsS -X POST "$BASE/api/run" \
    -H 'Content-Type: application/json' \
    -d '{"command":"echo","args":"profiler-smoke-test","timeout_ms":3000}')
echo "$RUN" | grep -q 'profiler-smoke-test' || fail "echo stdout not captured"
echo "$RUN" | grep -q '"status":"completed"'  || fail "echo status not completed"
echo "$RUN" | grep -q '"wall_ms"'             || fail "wall_ms missing"
pass "POST /api/run (echo)"

# ── 3. Run pwd ───────────────────────────────────────────────
PWD_R=$(curl -fsS -X POST "$BASE/api/run" \
    -H 'Content-Type: application/json' \
    -d '{"command":"pwd","args":"","timeout_ms":3000}')
echo "$PWD_R" | grep -q '"status":"completed"' || fail "pwd did not complete"
pass "POST /api/run (pwd)"

# ── 4. History populated ─────────────────────────────────────
HIST=$(curl -fsS "$BASE/api/history")
echo "$HIST" | grep -q '"command":"echo"' || fail "echo not in history"
pass "GET /api/history"

# ── 5. Stats endpoint ────────────────────────────────────────
STATS=$(curl -fsS "$BASE/api/stats")
echo "$STATS" | grep -q '"command"' || fail "stats missing command field"
pass "GET /api/stats"

# ── 6. Allowlist enforcement ─────────────────────────────────
CODE=$(curl -s -o /tmp/profiler-smoke-denied.json \
    -w '%{http_code}' -X POST "$BASE/api/run" \
    -H 'Content-Type: application/json' \
    -d '{"command":"sh","args":"-c id","timeout_ms":3000}')
[ "$CODE" = "403" ] || fail "sh not rejected (got HTTP $CODE)"
pass "allowlist blocks 'sh'"

# ── 7. /api/monitor (this process) ──────────────────────────
MON=$(curl -fsS "$BASE/api/monitor?pid=$$")
echo "$MON" | grep -q 'read_only_snapshot' || fail "/api/monitor missing mode field"
echo "$MON" | grep -q '"vmrss_kb"'         || fail "/api/monitor missing vmrss_kb"
pass "GET /api/monitor?pid=$$"

# ── 8. Syscall trace ─────────────────────────────────────────
TRACE=$(curl -fsS -X POST "$BASE/api/trace" \
    -H 'Content-Type: application/json' \
    -d '{"command":"echo","args":"trace-test","timeout_ms":5000}' || echo '{"total_syscalls":0}')
# Tracing may be disabled in restricted WSL; check for either success or known error
if echo "$TRACE" | grep -q '"total_syscalls"'; then
    pass "POST /api/trace (syscall tracing)"
else
    echo "SKIP: syscall tracing not available in this environment (ptrace restricted)"
fi

# ── 9. Timeout ───────────────────────────────────────────────
TOUT=$(curl -fsS -X POST "$BASE/api/run" \
    -H 'Content-Type: application/json' \
    -d '{"command":"sleep","args":"10","timeout_ms":300}')
echo "$TOUT" | grep -q '"status":"timed_out"' || fail "sleep did not time out"
pass "timeout enforcement"

# ── 10. Static file serving ──────────────────────────────────
HTTP_CODE=$(curl -s -o /dev/null -w '%{http_code}' "$BASE/")
[ "$HTTP_CODE" = "200" ] || fail "index.html not served (got $HTTP_CODE)"
pass "static file serving (index.html)"

echo ""
echo "=== All smoke tests passed. ==="
