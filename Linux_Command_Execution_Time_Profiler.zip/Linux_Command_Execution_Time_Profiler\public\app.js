/**
 * app.js – Linux Command Execution Time Profiler frontend
 *
 * No external libraries. Uses the Fetch API, Canvas 2D, and vanilla DOM.
 * All API calls go to /api/* on the same origin (127.0.0.1:8080).
 */
'use strict';

/* ─────────────── Utilities ─────────────── */

const $ = (id) => document.getElementById(id);
const fmt = (n, d = 2) => Number(n || 0).toFixed(d);
const fmtN = (n) => Number(n || 0).toLocaleString();
const safeStr = (v) => String(v ?? '');

/**
 * api(path, opts) – fetch JSON from the C server.
 * Throws an Error with a human-readable message on non-2xx responses.
 */
async function api(path, opts = {}) {
  const r = await fetch(path, opts);
  const data = await r.json();
  if (!r.ok) throw new Error(data.error || `HTTP ${r.status}`);
  return data;
}

/** POST JSON body to the server */
function postJSON(path, body) {
  return api(path, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
}

/* ─────────────── Tab switching ─────────────── */

document.querySelectorAll('.tab').forEach((btn) => {
  btn.addEventListener('click', () => {
    const target = btn.dataset.tab;
    document.querySelectorAll('.tab').forEach((t) => t.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach((p) => p.classList.add('hidden'));
    btn.classList.add('active');
    $(`tab-${target}`).classList.remove('hidden');
  });
});

/* ─────────────── Status pill colour ─────────────── */

function applyStatusClass(el, status) {
  el.className = 'status-pill';
  const s = safeStr(status).replace(/_/g, '-');
  el.classList.add(`s-${safeStr(status)}`);
  el.textContent = safeStr(status).replace(/_/g, ' ').toUpperCase();
}

/* ─────────────── Metric card builder ─────────────── */

function metricCard(label, value, highlight = false) {
  const d = document.createElement('div');
  d.className = 'metric-card' + (highlight ? ' highlight' : '');
  d.innerHTML = `<div class="label">${label}</div><div class="value">${value}</div>`;
  return d;
}

function populateMetrics(containerId, items) {
  const c = $(containerId);
  c.innerHTML = '';
  items.forEach(([lbl, val, hi]) => c.appendChild(metricCard(lbl, val, hi)));
}

/* ─────────────── Simple SVG bar chart ─────────────── */

/**
 * renderBarChart – render a bar chart into a container div.
 * @param {string} containerId  – id of the .chart-area div
 * @param {Array}  rows         – [{label, value, color}]
 * @param {string} title        – optional heading
 * @param {string} unit         – unit suffix (e.g. "ms", "KB")
 */
function renderBarChart(containerId, rows, title = '', unit = '') {
  const c = $(containerId);
  if (!c || !rows.length) return;

  const maxVal = Math.max(...rows.map((r) => r.value), 0.001);
  const colors = [
    '#2e5be8', '#10b981', '#f59e0b', '#ef4444',
    '#8b5cf6', '#06b6d4', '#84cc16', '#f97316',
  ];

  let html = title ? `<h3>${title}</h3>` : '';
  rows.forEach((row, i) => {
    const pct = Math.max(2, (row.value / maxVal) * 100);
    const color = row.color || colors[i % colors.length];
    html += `
      <div class="bar-row">
        <span class="bar-label">${row.label}</span>
        <div class="bar-track">
          <div class="bar-fill" style="width:${pct}%;background:${color}"></div>
        </div>
        <span class="bar-val">${fmt(row.value)} ${unit}</span>
      </div>`;
  });

  c.style.display = 'block';
  c.innerHTML = html;
}

/* ─────────────── Canvas RSS timeline chart ─────────────── */

const rssSamples = []; // {time, rss}

function drawRSSCanvas(samples) {
  const canvas = $('rss-canvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const W = canvas.width;
  const H = canvas.height;

  ctx.clearRect(0, 0, W, H);

  if (samples.length < 2) {
    ctx.fillStyle = '#6b7a99';
    ctx.font = '13px Inter, sans-serif';
    ctx.fillText('Collecting data…', 16, H / 2);
    return;
  }

  const maxRSS = Math.max(...samples.map((s) => s.rss), 1);
  const minRSS = Math.min(...samples.map((s) => s.rss), 0);
  const range  = maxRSS - minRSS || 1;
  const pad    = { t: 12, r: 10, b: 26, l: 60 };

  const toX = (i) => pad.l + ((i) / (samples.length - 1)) * (W - pad.l - pad.r);
  const toY = (v) => pad.t + (1 - (v - minRSS) / range) * (H - pad.t - pad.b);

  /* Grid lines */
  ctx.strokeStyle = '#dde3ef';
  ctx.lineWidth = 1;
  for (let i = 0; i <= 4; i++) {
    const y = pad.t + (i / 4) * (H - pad.t - pad.b);
    ctx.beginPath(); ctx.moveTo(pad.l, y); ctx.lineTo(W - pad.r, y);
    ctx.stroke();
    ctx.fillStyle = '#6b7a99';
    ctx.font = '10px Inter, sans-serif';
    ctx.textAlign = 'right';
    const val = maxRSS - (i / 4) * range;
    ctx.fillText(Math.round(val) + ' KB', pad.l - 4, y + 4);
  }

  /* Line */
  ctx.strokeStyle = '#2e5be8';
  ctx.lineWidth = 2.5;
  ctx.lineJoin = 'round';
  ctx.beginPath();
  samples.forEach((s, i) => {
    const x = toX(i), y = toY(s.rss);
    i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
  });
  ctx.stroke();

  /* Fill under line */
  ctx.fillStyle = 'rgba(46,91,232,.10)';
  ctx.beginPath();
  samples.forEach((s, i) => {
    const x = toX(i), y = toY(s.rss);
    i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
  });
  ctx.lineTo(toX(samples.length - 1), H - pad.b);
  ctx.lineTo(toX(0), H - pad.b);
  ctx.closePath();
  ctx.fill();

  /* X labels (first and last) */
  ctx.fillStyle = '#6b7a99';
  ctx.font = '10px Inter, sans-serif';
  ctx.textAlign = 'left';
  ctx.fillText(samples[0].time, pad.l, H - pad.b + 14);
  ctx.textAlign = 'right';
  ctx.fillText(samples[samples.length - 1].time, W - pad.r, H - pad.b + 14);
}

/* ─────────────── Load command allowlist ─────────────── */

async function loadCommands() {
  const { commands } = await api('/api/allowlist');
  const opts = commands.map((c) => `<option value="${c}">${c}</option>`).join('');
  ['cmd-run', 'cmd-repeat', 'cmd-compareA', 'cmd-compareB', 'cmd-trace'].forEach((id) => {
    if ($(id)) $(id).innerHTML = opts;
  });
  // Default compareB to sleep for variety
  if ($('cmd-compareB')) $('cmd-compareB').value = 'sleep';
}

/* ─────────────── TAB: Run ─────────────── */

$('runForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  $('run-error').classList.add('hidden');
  const btn = $('runBtn');
  btn.disabled = true;
  btn.textContent = '⏳ Profiling…';

  const payload = {
    command:    $('cmd-run').value,
    args:       $('args-run').value.trim(),
    timeout_ms: Number($('timeout-run').value) || 5000,
  };

  try {
    const r = await postJSON('/api/run', payload);
    showRunResult(r);
    await loadHistory();
  } catch (err) {
    $('run-error').textContent = err.message;
    $('run-error').classList.remove('hidden');
  } finally {
    btn.disabled = false;
    btn.textContent = '▶ Run Profiler';
  }
});

function showRunResult(r) {
  $('run-result').classList.remove('hidden');
  applyStatusClass($('run-status'), r.status);

  populateMetrics('run-metrics', [
    ['Wall Time',           fmt(r.wall_ms) + ' ms', true],
    ['User CPU',            fmt(r.user_ms) + ' ms'],
    ['System CPU',          fmt(r.system_ms) + ' ms'],
    ['Max RSS',             fmtN(r.max_rss_kb) + ' KB'],
    ['Minor Faults',        fmtN(r.minor_faults)],
    ['Major Faults',        fmtN(r.major_faults)],
    ['Voluntary Switches',  fmtN(r.voluntary_cs)],
    ['Involuntary Switches',fmtN(r.involuntary_cs)],
    ['Exit Code',           r.exit_code],
    ['Signal',              r.term_signal || '—'],
  ]);

  $('run-stdout').textContent = safeStr(r.stdout) || '(empty)';
  $('run-stderr').textContent = safeStr(r.stderr) || '(empty)';

  renderBarChart('run-chart', [
    { label: 'Wall Time',  value: r.wall_ms },
    { label: 'User CPU',   value: r.user_ms },
    { label: 'System CPU', value: r.system_ms },
  ], 'Time Breakdown (ms)', 'ms');
}

/* ─────────────── TAB: Repeat ─────────────── */

$('repeatBtn').addEventListener('click', async () => {
  $('repeat-error').classList.add('hidden');
  const btn = $('repeatBtn');
  btn.disabled = true;
  btn.textContent = '⏳ Running…';

  const count   = Math.max(2, Math.min(20, Number($('repeat-count').value) || 5));
  const command = $('cmd-repeat').value;
  const args    = $('args-repeat').value.trim();
  const timeout = Number($('timeout-repeat').value) || 5000;
  const payload = { command, args, timeout_ms: timeout };

  const allSamples = [];

  try {
    for (let i = 0; i < count; i++) {
      btn.textContent = `⏳ Run ${i + 1}/${count}…`;
      const r = await postJSON('/api/run', payload);
      allSamples.push(r);
    }

    const wallVals = allSamples
      .filter((r) => r.status === 'completed')
      .map((r) => Number(r.wall_ms));

    if (!wallVals.length) {
      $('repeat-error').textContent = 'No successful runs to summarise.';
      $('repeat-error').classList.remove('hidden');
      return;
    }

    const mean = wallVals.reduce((a, b) => a + b, 0) / wallVals.length;
    const variance = wallVals.reduce((a, b) => a + (b - mean) ** 2, 0) / wallVals.length;
    const stddev = Math.sqrt(variance);
    const min  = Math.min(...wallVals);
    const max  = Math.max(...wallVals);

    $('repeat-result').classList.remove('hidden');
    populateMetrics('repeat-metrics', [
      ['Total Runs',       count],
      ['Successful',       wallVals.length, true],
      ['Minimum',          fmt(min) + ' ms'],
      ['Mean',             fmt(mean) + ' ms', true],
      ['Maximum',          fmt(max) + ' ms'],
      ['Std. Deviation',   fmt(stddev) + ' ms'],
    ]);

    /* Per-run wall times as a bar chart */
    renderBarChart('repeat-chart',
      wallVals.map((v, i) => ({ label: `Run ${i + 1}`, value: v })),
      'Wall Time per Run (ms)', 'ms');

    await loadHistory();
  } catch (err) {
    $('repeat-error').textContent = err.message;
    $('repeat-error').classList.remove('hidden');
  } finally {
    btn.disabled = false;
    btn.textContent = '🔁 Run Analysis';
  }
});

/* ─────────────── TAB: Compare ─────────────── */

$('compareBtn').addEventListener('click', async () => {
  $('compare-error').classList.add('hidden');
  const btn = $('compareBtn');
  btn.disabled = true;
  btn.textContent = '⏳ Comparing…';

  const timeout = Number($('timeout-compare').value) || 5000;
  const pA = {
    command:    $('cmd-compareA').value,
    args:       $('args-compareA').value.trim(),
    timeout_ms: timeout,
  };
  const pB = {
    command:    $('cmd-compareB').value,
    args:       $('args-compareB').value.trim(),
    timeout_ms: timeout,
  };

  try {
    const [rA, rB] = await Promise.all([
      postJSON('/api/run', pA),
      postJSON('/api/run', pB),
    ]);

    showCompareResult(pA.command, rA, pB.command, rB);
    await loadHistory();
  } catch (err) {
    $('compare-error').textContent = err.message;
    $('compare-error').classList.remove('hidden');
  } finally {
    btn.disabled = false;
    btn.textContent = '⚖ Compare';
  }
});

function compareCard(name, r) {
  const statusClass = `s-${r.status}`;
  return `
    <div class="compare-card">
      <h3>${name}</h3>
      <p><span class="status-pill ${statusClass}">${safeStr(r.status).toUpperCase()}</span></p>
      <table style="margin-top:12px;width:100%;font-size:13px">
        <tr><td style="color:var(--text-muted)">Wall time</td>
            <td><strong>${fmt(r.wall_ms)} ms</strong></td></tr>
        <tr><td style="color:var(--text-muted)">User CPU</td>
            <td>${fmt(r.user_ms)} ms</td></tr>
        <tr><td style="color:var(--text-muted)">System CPU</td>
            <td>${fmt(r.system_ms)} ms</td></tr>
        <tr><td style="color:var(--text-muted)">Max RSS</td>
            <td>${fmtN(r.max_rss_kb)} KB</td></tr>
        <tr><td style="color:var(--text-muted)">Exit code</td>
            <td>${r.exit_code}</td></tr>
      </table>
    </div>`;
}

function showCompareResult(nameA, rA, nameB, rB) {
  $('compare-result').classList.remove('hidden');
  $('compare-cards').innerHTML = compareCard(nameA, rA) + compareCard(nameB, rB);

  /* Multi-metric comparison chart */
  const chartDiv = $('compare-chart');
  const maxWall = Math.max(rA.wall_ms, rB.wall_ms, 0.001);
  const maxCPU  = Math.max(rA.user_ms + rA.system_ms, rB.user_ms + rB.system_ms, 0.001);
  const maxRSS  = Math.max(rA.max_rss_kb, rB.max_rss_kb, 1);

  function barRow(label, valA, valB, maxVal, unit, color) {
    const pA = Math.max(2, (valA / maxVal) * 100);
    const pB = Math.max(2, (valB / maxVal) * 100);
    return `
      <div style="margin-bottom:14px">
        <div style="font-size:12px;font-weight:700;color:var(--text-muted);margin-bottom:6px">${label}</div>
        <div class="bar-row">
          <span class="bar-label">${nameA}</span>
          <div class="bar-track"><div class="bar-fill" style="width:${pA}%;background:#2e5be8"></div></div>
          <span class="bar-val">${fmt(valA)} ${unit}</span>
        </div>
        <div class="bar-row">
          <span class="bar-label">${nameB}</span>
          <div class="bar-track"><div class="bar-fill" style="width:${pB}%;background:#10b981"></div></div>
          <span class="bar-val">${fmt(valB)} ${unit}</span>
        </div>
      </div>`;
  }

  chartDiv.innerHTML =
    '<h3>Side-by-Side Comparison</h3>' +
    barRow('Wall Time', rA.wall_ms, rB.wall_ms, maxWall, 'ms') +
    barRow('Total CPU (user+system)', rA.user_ms + rA.system_ms, rB.user_ms + rB.system_ms, maxCPU, 'ms') +
    barRow('Max RSS', rA.max_rss_kb, rB.max_rss_kb, maxRSS, 'KB');
}

/* ─────────────── TAB: Syscall Trace ─────────────── */

$('traceBtn').addEventListener('click', async () => {
  $('trace-error').classList.add('hidden');
  const btn = $('traceBtn');
  btn.disabled = true;
  btn.textContent = '⏳ Tracing…';

  const payload = {
    command:    $('cmd-trace').value,
    args:       $('args-trace').value.trim(),
    timeout_ms: Number($('timeout-trace').value) || 5000,
  };

  try {
    const r = await postJSON('/api/trace', payload);
    showTraceResult(payload.command, r);
  } catch (err) {
    $('trace-error').textContent = err.message;
    $('trace-error').classList.remove('hidden');
  } finally {
    btn.disabled = false;
    btn.textContent = '🔬 Run Syscall Trace';
  }
});

function showTraceResult(cmd, r) {
  $('trace-result').classList.remove('hidden');

  populateMetrics('trace-summary', [
    ['Command',        cmd],
    ['Total Syscalls', fmtN(r.total_syscalls), true],
    ['Timed Out',      r.timed_out ? 'YES' : 'no'],
    ['Exit Code',      r.exit_code ?? '—'],
  ]);

  /* Table */
  const rows = (r.summary || []).map((s) => `
    <tr>
      <td>${s.number}</td>
      <td class="mono">${safeStr(s.name)}</td>
      <td>${fmtN(s.count)}</td>
      <td>${fmt(s.total_elapsed_ms, 4)} ms</td>
      <td>${fmt(s.average_elapsed_ms, 6)} ms</td>
    </tr>`).join('');

  $('trace-table-wrap').innerHTML = `
    <table>
      <thead><tr>
        <th>#</th><th>Name</th><th>Count</th>
        <th>Total Time</th><th>Avg Time</th>
      </tr></thead>
      <tbody>${rows || '<tr><td colspan="5">No syscalls recorded.</td></tr>'}</tbody>
    </table>`;

  /* Bar chart of counts */
  const summary = r.summary || [];
  if (summary.length) {
    renderBarChart('trace-chart',
      summary.map((s) => ({ label: s.name, value: s.count })),
      'Syscall Count (top 10)', 'calls');
  }
}

/* ─────────────── TAB: Monitor PID ─────────────── */

let pidWatchTimer = null;

$('monitorBtn').addEventListener('click', async () => {
  await snapshotPid();
});

async function snapshotPid() {
  $('monitor-error').classList.add('hidden');
  const pid = Number($('pid-input').value);
  if (!Number.isInteger(pid) || pid < 2) {
    $('monitor-error').textContent = 'Enter a valid PID (integer ≥ 2).';
    $('monitor-error').classList.remove('hidden');
    return;
  }

  try {
    const d = await api(`/api/monitor?pid=${pid}`);
    showMonitorResult(pid, d);
  } catch (err) {
    $('monitor-error').textContent = err.message;
    $('monitor-error').classList.remove('hidden');
  }
}

function showMonitorResult(pid, d) {
  $('monitor-result').classList.remove('hidden');
  const badge = $('monitor-pid-badge');
  badge.className = 'status-pill s-default';
  badge.textContent = `PID ${pid}`;

  populateMetrics('monitor-metrics', [
    ['Name',          safeStr(d.name)],
    ['State',         safeStr(d.state), true],
    ['RSS',           fmtN(d.vmrss_kb) + ' KB'],
    ['Virtual Mem',   fmtN(d.vmsize_kb) + ' KB'],
    ['Threads',       fmtN(d.threads)],
    ['utime (ticks)', fmtN(d.utime_ticks)],
    ['stime (ticks)', fmtN(d.stime_ticks)],
    ['Source',        '/proc/' + pid + '/status'],
  ]);

  $('monitor-raw').textContent = JSON.stringify(d, null, 2);
}

$('watchBtn').addEventListener('click', () => {
  if (pidWatchTimer) {
    clearInterval(pidWatchTimer);
    pidWatchTimer = null;
    $('watchBtn').textContent = '▶ Live Watch';
    return;
  }

  const pid = Number($('pid-input').value);
  if (!pid || pid < 2) {
    $('monitor-error').textContent = 'Enter a valid PID first.';
    $('monitor-error').classList.remove('hidden');
    return;
  }

  rssSamples.length = 0;
  $('monitor-chart').style.display = 'block';

  async function poll() {
    try {
      const d = await api(`/api/monitor?pid=${pid}`);
      showMonitorResult(pid, d);
      rssSamples.push({
        time: new Date().toLocaleTimeString(),
        rss:  Number(d.vmrss_kb) || 0,
      });
      if (rssSamples.length > 60) rssSamples.shift();
      drawRSSCanvas(rssSamples);
    } catch {
      clearInterval(pidWatchTimer);
      pidWatchTimer = null;
      $('watchBtn').textContent = '▶ Live Watch';
    }
  }

  poll();
  pidWatchTimer = setInterval(poll, 1000);
  $('watchBtn').textContent = '⏹ Stop Watch';
});

/* ─────────────── TAB: History ─────────────── */

async function loadHistory() {
  try {
    const { runs } = await api('/api/history');
    const tbody = $('history-body');
    if (!runs.length) {
      tbody.innerHTML = '<tr><td colspan="8" style="color:var(--text-muted)">No runs yet.</td></tr>';
      return;
    }
    tbody.innerHTML = runs.map((r) => {
      const sc = `s-${r.status}`;
      return `<tr>
        <td>${r.id}</td>
        <td>${safeStr(r.created_at)}</td>
        <td class="mono">${safeStr(r.command)} ${safeStr(r.args)}</td>
        <td><span class="status-pill ${sc}">${safeStr(r.status).toUpperCase()}</span></td>
        <td>${fmt(r.wall_ms)}</td>
        <td>${fmt(Number(r.user_ms) + Number(r.system_ms))}</td>
        <td>${fmtN(r.max_rss_kb)}</td>
        <td>${r.exit_code}</td>
      </tr>`;
    }).join('');
  } catch (err) {
    $('history-body').innerHTML =
      `<tr><td colspan="8" style="color:var(--danger)">${err.message}</td></tr>`;
  }
}

$('historyRefresh').addEventListener('click', loadHistory);

/* ─────────────── TAB: Stats ─────────────── */

async function loadStats() {
  try {
    const { stats } = await api('/api/stats');
    const tbody = $('stats-body');
    if (!stats.length) {
      tbody.innerHTML = '<tr><td colspan="8" style="color:var(--text-muted)">No data yet.</td></tr>';
      return;
    }
    tbody.innerHTML = stats.map((s) => `
      <tr>
        <td class="mono"><strong>${safeStr(s.command)}</strong></td>
        <td>${s.runs}</td>
        <td>${s.ok}</td>
        <td>${fmt(s.min_ms)}</td>
        <td>${fmt(s.avg_ms)}</td>
        <td>${fmt(s.max_ms)}</td>
        <td>${fmt(s.avg_cpu_ms)}</td>
        <td>${fmt(s.avg_rss_kb, 0)}</td>
      </tr>`).join('');

    /* Average wall time bar chart */
    renderBarChart('stats-chart',
      stats.filter((s) => s.runs > 0).map((s) => ({
        label: s.command,
        value: s.avg_ms,
      })),
      'Average Wall Time per Command (ms)', 'ms');

  } catch (err) {
    $('stats-body').innerHTML =
      `<tr><td colspan="8" style="color:var(--danger)">${err.message}</td></tr>`;
  }
}

$('statsRefresh').addEventListener('click', loadStats);

/* Also refresh stats when the stats tab is clicked */
document.querySelectorAll('.tab').forEach((btn) => {
  btn.addEventListener('click', () => {
    if (btn.dataset.tab === 'stats')   loadStats();
    if (btn.dataset.tab === 'history') loadHistory();
  });
});

/* ─────────────── Initialise ─────────────── */

(async () => {
  try {
    await loadCommands();
    await loadHistory();
  } catch (err) {
    console.error('Init failed:', err);
  }
})();
