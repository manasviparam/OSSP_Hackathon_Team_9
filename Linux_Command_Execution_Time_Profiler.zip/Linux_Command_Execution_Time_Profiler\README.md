# Linux Command Execution Time Profiler

A systems-programming project that exposes a web dashboard for measuring how
Linux commands consume CPU, memory, I/O, and kernel resources.  
Everything runs locally on Ubuntu 24.04 (including WSL) — the backend is
pure C and the frontend is plain HTML / CSS / JavaScript.

---

## Features

| Feature | Details |
|---------|---------|
| **Command execution** | `fork()` + `execvp()` + `wait4()` — never `system()` or `sh -c` |
| **Wall-clock timing** | `clock_gettime(CLOCK_MONOTONIC)` |
| **User / System CPU** | `struct rusage` via `wait4()` |
| **Max RSS** | `ru_maxrss` (KiB on Linux) |
| **Page faults** | `ru_minflt` / `ru_majflt` |
| **Context switches** | `ru_nvcsw` / `ru_nivcsw` |
| **stdout / stderr** | captured via `pipe()` + `dup2()` + non-blocking drain loop |
| **Timeouts** | configurable ms → SIGTERM → 150 ms grace → SIGKILL |
| **Syscall tracing** | `ptrace(PTRACE_SYSCALL)` counts + timing on x86_64 |
| **Process monitor** | reads `/proc/<pid>/status` and `/proc/<pid>/stat` (read-only) |
| **History** | every run stored in SQLite; latest 100 shown in dashboard |
| **Per-command stats** | min / avg / max wall time computed in SQL |
| **Repeat analysis** | N runs → min / mean / max / stddev of wall time |
| **Command comparison** | two commands, same timeout, side-by-side chart |
| **Live RSS chart** | canvas-based timeline for any running PID |
| **Allowlist** | only 20 pre-approved commands; shell metacharacters rejected |
| **Security** | binds to `127.0.0.1` only; no shell expansion; no path traversal |

---

## Technology Stack

| Layer | Technology |
|-------|-----------|
| Backend / profiler | C (gcc, `-std=c11`) |
| HTTP server | hand-written in C (`src/server.c`, `src/http.c`) |
| Database | SQLite 3 (`src/db.c`) |
| Frontend | HTML5 + CSS3 + vanilla JavaScript (no frameworks) |
| Environment | Ubuntu 24.04 LTS on WSL2 (also bare Linux) |

---

## OS Concepts Demonstrated

- **`fork()` / `execvp()`** — spawn child without shell
- **`wait4()` / `getrusage()`** — reap child and collect resource usage
- **`pipe()` / `dup2()`** — capture stdout and stderr
- **`clock_gettime(CLOCK_MONOTONIC)`** — high-resolution wall-clock timing
- **`setpgid()` / `kill(-pgid, SIG)`** — kill entire process group on timeout
- **`sigaction()` / `SIGCHLD` / `SA_RESTART`** — zombie-free child reaping
- **`SIGTERM` / `SIGKILL`** — graceful then hard termination
- **`ptrace(PTRACE_TRACEME)` / `ptrace(PTRACE_SYSCALL)`** — syscall tracing
- **`/proc/<pid>/status`** and **`/proc/<pid>/stat`** — live process inspection
- **SQLite WAL** — concurrent-safe persistent storage

---

## Requirements

Ubuntu 24.04 LTS (bare or WSL2).

```bash
sudo apt update
sudo apt install -y build-essential libsqlite3-dev curl
```

Verify:
```bash
gcc --version     # should be ≥ 13
sqlite3 --version # should be ≥ 3.37
```

---

## Installation and Build

```bash
# 1. Clone or extract the project
cd Linux_Command_Execution_Time_Profiler

# 2. Build
make

# Expected output:
# Build successful: ./profiler_server
```

---

## Running the Server

```bash
# Default port 8080
./profiler_server

# Custom port
./profiler_server 8090
```

Then open **<http://127.0.0.1:8080>** in your browser (works from Windows
if running under WSL2, since WSL2 bridges the loopback automatically).

Stop the server with **Ctrl+C**.

---

## Dashboard Tabs

| Tab | Description |
|-----|-------------|
| **Run** | Select command, enter arguments, set timeout, view all metrics + stdout/stderr + time breakdown chart |
| **Repeat** | Run the same command N times (2–20), view min/mean/max/stddev and per-run bar chart |
| **Compare** | Run two commands simultaneously, side-by-side cards and multi-metric chart |
| **Syscall Trace** | ptrace pass — total syscall count, per-syscall count and elapsed time, bar chart |
| **Monitor PID** | Snapshot `/proc/<pid>/status`; Start Live Watch for a 1-second-polling RSS timeline |
| **History** | Latest 100 runs from SQLite |
| **Stats** | Per-command aggregates (min/avg/max wall time, avg CPU, avg RSS) with bar chart |

---

## Automated Tests

```bash
make test
```

This runs:

1. **`tests/smoke_test.sh`** – 10 checks:
   - allowlist endpoint
   - `echo` run (stdout captured)
   - `pwd` run
   - history persistence
   - `/api/stats`
   - allowlist rejection of `sh`
   - `/api/monitor` (this shell's PID)
   - syscall tracing (skipped gracefully if ptrace restricted)
   - timeout enforcement (`sleep 10` with 300 ms limit)
   - static file serving

2. **`tests/scenario_test.sh`** – 12 scenarios:
   - `cat` reads file contents
   - `sort` produces sorted output
   - `wc -l` counts lines
   - `grep` nonexistent → nonzero exit → `status: failed`
   - `echo` stdout captured
   - `sleep` hit by timeout → `timed_out`
   - `bash` rejected (403)
   - semicolon in args rejected (400)
   - history contains recent runs
   - stats endpoint has data
   - `uname -a` mentions Linux
   - sequential runs accumulate in history

---

## API Reference

All endpoints are on `http://127.0.0.1:8080`.

### `GET /api/allowlist`
Returns the list of runnable command names.
```json
{"commands":["ls","pwd","echo","cat","head","tail","wc","sort","uniq","grep","find","sleep","gzip","date","whoami","uname","df","du","uptime","free"]}
```

### `POST /api/run`
Execute a command and return profiling metrics.

**Request body:**
```json
{"command":"echo","args":"hello world","timeout_ms":5000}
```

**Response:**
```json
{
  "status": "completed",
  "wall_ms": 2.341,
  "user_ms": 0.873,
  "system_ms": 0.411,
  "max_rss_kb": 1024,
  "minor_faults": 42,
  "major_faults": 0,
  "voluntary_cs": 1,
  "involuntary_cs": 0,
  "exit_code": 0,
  "term_signal": 0,
  "timed_out": false,
  "stdout": "hello world\n",
  "stderr": ""
}
```

### `POST /api/trace`
Run a command under `ptrace(PTRACE_SYSCALL)` and return syscall statistics.

**Request body:** same as `/api/run`

**Response:**
```json
{
  "total_syscalls": 47,
  "timed_out": false,
  "exit_code": 0,
  "summary": [
    {"number":231,"name":"exit_group","count":1,"total_elapsed_ms":0.0012,"average_elapsed_ms":0.0012},
    ...
  ]
}
```

### `GET /api/history`
Returns the latest 100 runs stored in SQLite.

### `GET /api/stats`
Returns per-command aggregate statistics (min/avg/max wall time, avg CPU, avg RSS).

### `GET /api/monitor?pid=<N>`
Returns a snapshot of `/proc/<N>/status` and `/proc/<N>/stat`.

---

## Security Notes

- The server listens only on `127.0.0.1` — never on a public interface.
- Only the 20 commands in the allowlist can be executed.
- Argument tokens are validated one-by-one; shell metacharacters
  (`;`, `|`, `` ` ``, `$(`, `&`, `>`, `<`) cause a 400 rejection.
- `system()`, `popen()`, and `sh -c` are never called.
- Path traversal (`..`) is rejected in file serving.

---

## ptrace Limitations on WSL

`ptrace` may be blocked by:

1. **Yama ptrace_scope** — fix:
   ```bash
   echo 0 | sudo tee /proc/sys/kernel/yama/ptrace_scope
   ```
2. **WSL seccomp profile** — some older WSL1/WSL2 builds restrict
   `PTRACE_TRACEME`.  Upgrade to the latest WSL2 kernel:
   ```bash
   wsl --update
   ```

The syscall trace endpoint returns a descriptive JSON error if ptrace
is unavailable; all other features continue to work.

---

## Project Structure

```
Linux_Command_Execution_Time_Profiler/
├── Makefile
├── README.md
├── include/
│   ├── db.h              # SQLite API declarations
│   ├── http.h            # HTTP server API
│   ├── profiler.h        # Profiler API and result struct
│   └── syscall_trace.h   # ptrace API
├── src/
│   ├── server.c          # Main server, request router, /proc monitor
│   ├── http.c            # HTTP/1.1 read/write helpers
│   ├── db.c              # SQLite open, insert, history, stats
│   ├── profiler.c        # fork/exec/wait4/rusage/pipe profiler
│   └── syscall_trace.c   # ptrace syscall counter and timer
├── public/
│   ├── index.html        # Dashboard (tabbed)
│   ├── style.css         # Responsive stylesheet
│   └── app.js            # All frontend logic (no dependencies)
├── tests/
│   ├── smoke_test.sh     # 10 smoke tests
│   └── scenario_test.sh  # 12 integration scenarios
└── db/
    └── profiler.db       # Created automatically at startup
```

---

## Troubleshooting

| Symptom | Cause | Fix |
|---------|-------|-----|
| `bind/listen: Address already in use` | Port 8080 taken | `./profiler_server 8090` |
| `Cannot initialize database` | `db/` not writable | `mkdir -p db && chmod 755 db` |
| `error: command is not on the allowlist` | Command not in the 20 allowed | Use an allowlisted command |
| ptrace returns permission error | Yama scope or WSL restriction | `echo 0 \| sudo tee /proc/sys/kernel/yama/ptrace_scope` |
| Browser shows "Connection refused" | Server not running | Check WSL terminal, run `./profiler_server` |
| Page not loading from Windows browser | WSL1 (no port forwarding) | Use WSL2 or access from inside WSL with `curl` |
| `libsqlite3-dev` not found | Package not installed | `sudo apt install -y libsqlite3-dev` |

---

## Building the ZIP

```bash
make zip
```
This creates `../Linux_Command_Execution_Time_Profiler.zip` (requires `zip`
to be installed: `sudo apt install -y zip`).

---

## Architecture Diagram

```
Browser (HTML/CSS/JS on Windows or Linux)
         |
         | HTTP / JSON  (loopback only: 127.0.0.1)
         v
┌─────────────────────────────────────────────┐
│  server.c  –  accept() loop                 │
│  ┌──────────────────────────────────────┐   │
│  │  fork() per request (child)          │   │
│  │  ┌────────────────────────────────┐  │   │
│  │  │  Route handler                 │  │   │
│  │  │  /api/run  → profiler_run()    │  │   │
│  │  │  /api/trace → syscall_trace_run│  │   │
│  │  │  /api/monitor → /proc/<pid>    │  │   │
│  │  │  /api/history → db_history_json│  │   │
│  │  │  /api/stats  → db_stats_json   │  │   │
│  │  └────────────────────────────────┘  │   │
│  └──────────────────────────────────────┘   │
│                                             │
│  profiler.c                                 │
│    fork() → execvp() → pipes → wait4()      │
│    clock_gettime · getrusage · poll()        │
│                                             │
│  syscall_trace.c                            │
│    fork() → PTRACE_TRACEME → execvp()       │
│    PTRACE_SYSCALL loop → entry/exit timing  │
│                                             │
│  db.c  –  SQLite WAL database               │
│    db/profiler.db  (all runs stored here)   │
└─────────────────────────────────────────────┘
```
