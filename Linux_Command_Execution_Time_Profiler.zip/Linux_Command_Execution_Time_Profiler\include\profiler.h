#ifndef PROFILER_H
#define PROFILER_H

/**
 * profile_result_t – holds all metrics captured for a single command run.
 *
 * Memory: `out` and `err` are heap-allocated strings.  Call
 * profiler_result_free() after use.
 */
typedef struct {
    char  *out;              /* captured stdout (NUL-terminated, heap) */
    char  *err;              /* captured stderr (NUL-terminated, heap) */
    double wall_ms;          /* real (wall-clock) elapsed time, ms */
    double user_ms;          /* user-mode CPU time, ms               */
    double system_ms;        /* kernel-mode CPU time, ms              */
    long   max_rss_kb;       /* peak resident set size, KiB           */
    long   minor_faults;     /* minor page faults (no I/O)            */
    long   major_faults;     /* major page faults (disk I/O)          */
    long   voluntary_cs;     /* voluntary context switches            */
    long   involuntary_cs;   /* involuntary context switches          */
    int    exit_code;        /* exit status if WIFEXITED, else -1     */
    int    term_signal;      /* signal number if WIFSIGNALED, else 0  */
    int    timed_out;        /* 1 if killed due to timeout            */
    char   status[32];       /* "completed", "failed", "timed_out",   */
                             /* "signal_terminated"                    */
} profile_result_t;

/**
 * profiler_run – fork/exec the given allowlisted command with args, measure
 * all OS-level metrics, and capture stdout/stderr.
 *
 * @command      bare executable name (must be in allowlist)
 * @args_text    space-separated argument string (shell operators rejected)
 * @timeout_ms   wall-clock timeout in milliseconds [100, 60000]
 * @result       output; caller must call profiler_result_free() afterwards
 * @return       0 on success, -1 on validation / system error
 */
int profiler_run(const char *command, const char *args_text,
                 int timeout_ms, profile_result_t *result);

/**
 * profiler_result_free – release heap memory inside a profile_result_t.
 */
void profiler_result_free(profile_result_t *result);

/**
 * command_is_allowed – return 1 if the bare command name is in the allowlist.
 */
int command_is_allowed(const char *command);

#endif /* PROFILER_H */
