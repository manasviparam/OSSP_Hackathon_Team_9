#ifndef SYSCALL_TRACE_H
#define SYSCALL_TRACE_H

#include <stddef.h>

/**
 * syscall_trace_run – run an allowlisted command under ptrace(PTRACE_SYSCALL)
 * and collect per-syscall invocation counts and cumulative elapsed times.
 *
 * stdout and stderr of the traced process are redirected to /dev/null so that
 * raw ptrace stops and regular output do not interleave.
 *
 * On x86_64 Linux the function returns a JSON object:
 *   {
 *     "total_syscalls": <N>,
 *     "timed_out": false,
 *     "summary": [
 *       { "number": 0, "name": "read",  "count": 3,
 *         "total_elapsed_ms": 0.0120, "average_elapsed_ms": 0.0040 },
 *       …  (top-10 by invocation count)
 *     ]
 *   }
 *
 * On other architectures or if ptrace is unavailable (e.g. restricted WSL),
 * the function returns -1 and writes an {"error":…} object to json_out.
 *
 * @command       bare executable name (must pass command_is_allowed())
 * @args_text     space-separated argument string
 * @timeout_ms    hard wall-clock limit [100, 60000]
 * @json_out      caller-supplied output buffer
 * @json_capacity size of json_out in bytes
 * @return 0 on success, -1 on error
 */
int syscall_trace_run(const char *command, const char *args_text,
                      int timeout_ms,
                      char *json_out, size_t json_capacity);

#endif /* SYSCALL_TRACE_H */
