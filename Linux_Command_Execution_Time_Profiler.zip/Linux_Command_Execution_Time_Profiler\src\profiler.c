/*
 * profiler.c - command execution and resource measurement
 */
#include "profiler.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <signal.h>
#include <time.h>
#include <poll.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/resource.h>

/* -------------------------------------------------------------------------
 * Allowlist – only these bare command names may be executed.
 * ------------------------------------------------------------------------- */
static const char *allowed[] = {
    "ls", "pwd", "echo", "cat", "head", "tail",
    "wc", "sort", "uniq", "grep", "find", "sleep",
    "gzip", "date", "whoami", "uname", "df", "du",
    "uptime", "free", NULL
};

int command_is_allowed(const char *c)
{
    if (!c || *c == '\0') return 0;
    for (int i = 0; allowed[i]; i++)
        if (strcmp(c, allowed[i]) == 0) return 1;
    return 0;
}

/* -------------------------------------------------------------------------
 * Internal helpers
 * ------------------------------------------------------------------------- */

/** Convert two timespec values to milliseconds elapsed. */
static double timespec_ms(struct timespec a, struct timespec b)
{
    return (b.tv_sec - a.tv_sec) * 1000.0
         + (b.tv_nsec - a.tv_nsec) / 1000000.0;
}

/** Grow *dst and append n bytes from p; enforces OUTPUT_LIMIT. */
#define OUTPUT_LIMIT (256 * 1024)

static void buf_append(char **dst, size_t *used, const char *p, size_t n)
{
    if (*used >= OUTPUT_LIMIT) return;
    if (n > OUTPUT_LIMIT - *used) n = OUTPUT_LIMIT - *used;
    char *q = realloc(*dst, *used + n + 1);
    if (!q) return;
    *dst = q;
    memcpy(q + *used, p, n);
    *used += n;
    q[*used] = '\0';
}

/**
 * parse_args – split args_text on whitespace into argv[1..],
 * validating that no shell metacharacters appear in individual tokens.
 *
 * @argv  pre-allocated array; argv[0] must already be set by the caller.
 * @max   maximum number of additional slots (argv is sized max+2 by caller).
 * @return number of arguments parsed, or -1 on validation failure.
 */
static int parse_args(const char *text, char **argv, int max)
{
    char *copy = strdup(text ? text : "");
    if (!copy) return -1;

    int n = 0;
    char *save = NULL;
    for (char *tok = strtok_r(copy, " \t\r\n", &save);
         tok && n < max - 2;
         tok = strtok_r(NULL, " \t\r\n", &save))
    {
        /* Reject shell injection patterns */
        if (strlen(tok) > 256
            || strchr(tok, ';') || strchr(tok, '|')
            || strchr(tok, '`') || strstr(tok, "$(")
            || strchr(tok, '&') || strchr(tok, '>')
            || strchr(tok, '<'))
        {
            free(copy);
            return -1;
        }
        argv[n] = strdup(tok);
        if (!argv[n]) { free(copy); return -1; }
        n++;
    }
    argv[n] = NULL;
    free(copy);
    return n;
}

static void free_argv(char **v)
{
    for (int i = 0; v[i]; i++) free(v[i]);
}

/* -------------------------------------------------------------------------
 * Public API
 * ------------------------------------------------------------------------- */

int profiler_run(const char *command, const char *args_text,
                 int timeout_ms, profile_result_t *r)
{
    memset(r, 0, sizeof(*r));
    r->exit_code = -1;
    strcpy(r->status, "failed");

    /* Validate inputs */
    if (!command_is_allowed(command)
        || timeout_ms < 100 || timeout_ms > 60000)
        return -1;

    /* Build argv: argv[0] = command, argv[1..] = parsed args */
    char *argv[68];
    memset(argv, 0, sizeof(argv));
    argv[0] = strdup(command);
    if (!argv[0]) return -1;

    int ac = parse_args(args_text, argv + 1, 66);
    if (ac < 0) { free(argv[0]); return -1; }

    /* Create two pipes: one for stdout, one for stderr */
    int po[2], pe[2];
    if (pipe(po) || pipe(pe)) {
        free_argv(argv);
        return -1;
    }

    /* Record wall-clock start */
    struct timespec wall_start, wall_end;
    clock_gettime(CLOCK_MONOTONIC, &wall_start);

    pid_t pid = fork();
    if (pid < 0) {
        close(po[0]); close(po[1]);
        close(pe[0]); close(pe[1]);
        free_argv(argv);
        return -1;
    }

    if (pid == 0) {
        /* ---- Child ------------------------------------------------ */
        /* Put the child in its own process group so kill(-pgid, …)
         * reaches all descendants. */
        setpgid(0, 0);

        /* Wire pipes: stdout -> po[1], stderr -> pe[1] */
        dup2(po[1], STDOUT_FILENO);
        dup2(pe[1], STDERR_FILENO);
        close(po[0]); close(po[1]);
        close(pe[0]); close(pe[1]);

        /* Execute the command; never use system() or sh -c */
        execvp(command, argv);

        /* execvp failed – report to parent via stderr pipe */
        dprintf(STDERR_FILENO, "execvp failed: %s\n", strerror(errno));
        _exit(127);
    }

    /* ---- Parent ---------------------------------------------------- */
    setpgid(pid, pid);           /* mirror child's pgid assignment    */
    close(po[1]);                /* close write ends in parent        */
    close(pe[1]);

    /* Make read ends non-blocking so we can poll() */
    fcntl(po[0], F_SETFL, fcntl(po[0], F_GETFL) | O_NONBLOCK);
    fcntl(pe[0], F_SETFL, fcntl(pe[0], F_GETFL) | O_NONBLOCK);

    /* ---- Drain loop ------------------------------------------------ */
    size_t ou = 0, eu = 0;
    int out_open = 1, err_open = 1, child_done = 0;
    int wstatus = 0;
    struct rusage ru;
    memset(&ru, 0, sizeof(ru));

    while (!child_done || out_open || err_open) {
        struct timespec now;
        clock_gettime(CLOCK_MONOTONIC, &now);

        /* Enforce timeout */
        if (!child_done && !r->timed_out
            && timespec_ms(wall_start, now) > timeout_ms)
        {
            r->timed_out = 1;
            /* Graceful first, then hard kill */
            kill(-pid, SIGTERM);
            usleep(150000);
            kill(-pid, SIGKILL);
        }

        struct pollfd fds[2] = {
            { po[0], POLLIN | POLLHUP, 0 },
            { pe[0], POLLIN | POLLHUP, 0 }
        };
        poll(fds, 2, 50);

        char buf[8192];

        /* Drain stdout */
        if (out_open && (fds[0].revents & (POLLIN | POLLHUP))) {
            ssize_t n;
            while ((n = read(po[0], buf, sizeof(buf))) > 0)
                buf_append(&r->out, &ou, buf, (size_t)n);
            if (n == 0) { out_open = 0; close(po[0]); }
        }

        /* Drain stderr */
        if (err_open && (fds[1].revents & (POLLIN | POLLHUP))) {
            ssize_t n;
            while ((n = read(pe[0], buf, sizeof(buf))) > 0)
                buf_append(&r->err, &eu, buf, (size_t)n);
            if (n == 0) { err_open = 0; close(pe[0]); }
        }

        /* Non-blocking wait; collect rusage with wait4() */
        if (!child_done) {
            pid_t w = wait4(pid, &wstatus, WNOHANG, &ru);
            if (w == pid) child_done = 1;
        }

        if (child_done && !out_open && !err_open) break;
    }

    /* Blocking wait in case we exited the loop early */
    if (!child_done) {
        while (wait4(pid, &wstatus, 0, &ru) < 0 && errno == EINTR) {}
    }

    /* ---- Record wall-clock end ------------------------------------- */
    clock_gettime(CLOCK_MONOTONIC, &wall_end);
    r->wall_ms = timespec_ms(wall_start, wall_end);

    /* ---- Populate rusage fields ------------------------------------ */
    r->user_ms   = ru.ru_utime.tv_sec * 1000.0
                 + ru.ru_utime.tv_usec / 1000.0;
    r->system_ms = ru.ru_stime.tv_sec * 1000.0
                 + ru.ru_stime.tv_usec / 1000.0;
    r->max_rss_kb     = ru.ru_maxrss;
    r->minor_faults   = ru.ru_minflt;
    r->major_faults   = ru.ru_majflt;
    r->voluntary_cs   = ru.ru_nvcsw;
    r->involuntary_cs = ru.ru_nivcsw;

    /* ---- Determine exit/signal status ----------------------------- */
    if (WIFEXITED(wstatus)) {
        r->exit_code = WEXITSTATUS(wstatus);
        if (r->timed_out)
            strcpy(r->status, "timed_out");
        else if (r->exit_code == 0)
            strcpy(r->status, "completed");
        else
            strcpy(r->status, "failed");
    } else if (WIFSIGNALED(wstatus)) {
        r->term_signal = WTERMSIG(wstatus);
        strcpy(r->status, r->timed_out ? "timed_out" : "signal_terminated");
    }

    /* Ensure non-NULL output strings */
    if (!r->out) r->out = strdup("");
    if (!r->err) r->err = strdup("");

    free_argv(argv);
    return 0;
}

void profiler_result_free(profile_result_t *r)
{
    free(r->out);
    free(r->err);
    memset(r, 0, sizeof(*r));
}
