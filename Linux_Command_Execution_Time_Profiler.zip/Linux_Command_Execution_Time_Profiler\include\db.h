#ifndef DB_H
#define DB_H

#include <sqlite3.h>

/**
 * db_open – open (or create) the SQLite database at *path* and ensure all
 * required tables exist with WAL journal mode enabled.
 *
 * @db   output: opened database handle
 * @path file-system path to the .db file
 * @return 0 on success, -1 on failure (details printed to stderr)
 */
int db_open(sqlite3 **db, const char *path);

/**
 * db_add_run – insert one profiling result row into the *runs* table.
 *
 * All text parameters are copied by SQLite; callers may free them afterwards.
 * @return 0 on success, -1 on failure
 */
int db_add_run(sqlite3 *db,
               const char *command, const char *args,
               double wall_ms, double user_ms, double system_ms,
               long max_rss_kb, long minor_faults, long major_faults,
               long voluntary_cs, long involuntary_cs,
               int exit_code, int term_signal,
               const char *status,
               const char *stdout_text, const char *stderr_text);

/**
 * db_history_json – return a JSON string containing the latest 100 runs.
 *
 * The string is allocated by SQLite's internal allocator.  Caller must call
 * sqlite3_free() on the returned pointer.
 * @return heap-allocated JSON or NULL on error
 */
char *db_history_json(sqlite3 *db);

/**
 * db_stats_json – return a JSON string with per-command aggregate statistics
 * (min / mean / max / stddev of wall_ms) computed in SQL.
 *
 * Caller must call sqlite3_free() on the returned pointer.
 */
char *db_stats_json(sqlite3 *db);

#endif /* DB_H */
