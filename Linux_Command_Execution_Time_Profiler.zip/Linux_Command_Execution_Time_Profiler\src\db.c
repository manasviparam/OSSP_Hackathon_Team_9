/*
 * db.c – SQLite persistence layer
 *
 * All public functions accept an already-opened sqlite3* handle.
 * Call db_open() first to initialize schema; call sqlite3_close() when done.
 */
#include "db.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* -------------------------------------------------------------------------
 * Schema
 * ------------------------------------------------------------------------- */
static const char *SCHEMA_SQL =
    "PRAGMA journal_mode=WAL;"
    "PRAGMA synchronous=NORMAL;"
    "CREATE TABLE IF NOT EXISTS runs("
    "  id           INTEGER PRIMARY KEY AUTOINCREMENT,"
    "  created_at   TEXT    DEFAULT CURRENT_TIMESTAMP,"
    "  command      TEXT    NOT NULL,"
    "  args         TEXT,"
    "  wall_ms      REAL,"
    "  user_ms      REAL,"
    "  system_ms    REAL,"
    "  max_rss_kb   INTEGER,"
    "  minor_faults INTEGER,"
    "  major_faults INTEGER,"
    "  voluntary_cs   INTEGER,"
    "  involuntary_cs INTEGER,"
    "  exit_code    INTEGER,"
    "  term_signal  INTEGER,"
    "  status       TEXT,"
    "  stdout_text  TEXT,"
    "  stderr_text  TEXT"
    ");";

/* -------------------------------------------------------------------------
 * JSON helpers using SQLite's built-in string builder
 * ------------------------------------------------------------------------- */

/** Append a JSON-safe quoted string to an sqlite3_str. */
static void json_string(sqlite3_str *b, const unsigned char *s)
{
    sqlite3_str_appendchar(b, 1, '"');
    if (s) {
        for (; *s; s++) {
            unsigned char c = *s;
            if      (c == '"')  { sqlite3_str_appendchar(b, 1, '\\');
                                   sqlite3_str_appendchar(b, 1, '"'); }
            else if (c == '\\') { sqlite3_str_appendchar(b, 1, '\\');
                                   sqlite3_str_appendchar(b, 1, '\\'); }
            else if (c == '\n') { sqlite3_str_appendall(b, "\\n"); }
            else if (c == '\r') { sqlite3_str_appendall(b, "\\r"); }
            else if (c == '\t') { sqlite3_str_appendall(b, "\\t"); }
            else if (c >= 32)   { sqlite3_str_appendchar(b, 1, (char)c); }
        }
    }
    sqlite3_str_appendchar(b, 1, '"');
}

/* -------------------------------------------------------------------------
 * Public API
 * ------------------------------------------------------------------------- */

int db_open(sqlite3 **db, const char *path)
{
    if (sqlite3_open(path, db) != SQLITE_OK) {
        fprintf(stderr, "db_open: cannot open %s: %s\n",
                path, sqlite3_errmsg(*db));
        sqlite3_close(*db);
        *db = NULL;
        return -1;
    }

    sqlite3_busy_timeout(*db, 4000);

    char *err = NULL;
    if (sqlite3_exec(*db, SCHEMA_SQL, NULL, NULL, &err) != SQLITE_OK) {
        fprintf(stderr, "db_open: schema init failed: %s\n",
                err ? err : "unknown");
        sqlite3_free(err);
        sqlite3_close(*db);
        *db = NULL;
        return -1;
    }

    return 0;
}

int db_add_run(sqlite3 *db,
               const char *command, const char *args,
               double wall_ms, double user_ms, double system_ms,
               long max_rss_kb, long minor_faults, long major_faults,
               long voluntary_cs, long involuntary_cs,
               int exit_code, int term_signal,
               const char *status,
               const char *stdout_text, const char *stderr_text)
{
    const char *sql =
        "INSERT INTO runs("
        "  command,args,wall_ms,user_ms,system_ms,"
        "  max_rss_kb,minor_faults,major_faults,"
        "  voluntary_cs,involuntary_cs,"
        "  exit_code,term_signal,status,stdout_text,stderr_text"
        ") VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    sqlite3_stmt *s = NULL;
    if (sqlite3_prepare_v2(db, sql, -1, &s, NULL) != SQLITE_OK) return -1;

    sqlite3_bind_text  (s,  1, command,      -1, SQLITE_TRANSIENT);
    sqlite3_bind_text  (s,  2, args,         -1, SQLITE_TRANSIENT);
    sqlite3_bind_double(s,  3, wall_ms);
    sqlite3_bind_double(s,  4, user_ms);
    sqlite3_bind_double(s,  5, system_ms);
    sqlite3_bind_int64 (s,  6, max_rss_kb);
    sqlite3_bind_int64 (s,  7, minor_faults);
    sqlite3_bind_int64 (s,  8, major_faults);
    sqlite3_bind_int64 (s,  9, voluntary_cs);
    sqlite3_bind_int64 (s, 10, involuntary_cs);
    sqlite3_bind_int   (s, 11, exit_code);
    sqlite3_bind_int   (s, 12, term_signal);
    sqlite3_bind_text  (s, 13, status,       -1, SQLITE_TRANSIENT);
    sqlite3_bind_text  (s, 14, stdout_text ? stdout_text : "",
                               -1, SQLITE_TRANSIENT);
    sqlite3_bind_text  (s, 15, stderr_text ? stderr_text : "",
                               -1, SQLITE_TRANSIENT);

    int rc = (sqlite3_step(s) == SQLITE_DONE) ? 0 : -1;
    sqlite3_finalize(s);
    return rc;
}

char *db_history_json(sqlite3 *db)
{
    sqlite3_str *b = sqlite3_str_new(db);
    sqlite3_str_appendall(b, "{\"runs\":[");

    const char *sql =
        "SELECT id,created_at,command,args,"
        "       wall_ms,user_ms,system_ms,max_rss_kb,"
        "       minor_faults,major_faults,voluntary_cs,involuntary_cs,"
        "       exit_code,term_signal,status,stdout_text,stderr_text"
        " FROM runs ORDER BY id DESC LIMIT 100";

    sqlite3_stmt *s = NULL;
    if (sqlite3_prepare_v2(db, sql, -1, &s, NULL) != SQLITE_OK) {
        sqlite3_str_appendall(b, "]}");
        return sqlite3_str_finish(b);
    }

    int first = 1;
    while (sqlite3_step(s) == SQLITE_ROW) {
        if (!first) sqlite3_str_appendchar(b, 1, ',');
        first = 0;

        sqlite3_str_appendf(b, "{\"id\":%d,\"created_at\":",
                            sqlite3_column_int(s, 0));
        json_string(b, sqlite3_column_text(s, 1));

        sqlite3_str_appendall(b, ",\"command\":");
        json_string(b, sqlite3_column_text(s, 2));

        sqlite3_str_appendall(b, ",\"args\":");
        json_string(b, sqlite3_column_text(s, 3));

        sqlite3_str_appendf(b,
            ",\"wall_ms\":%.3f"
            ",\"user_ms\":%.3f"
            ",\"system_ms\":%.3f"
            ",\"max_rss_kb\":%lld"
            ",\"minor_faults\":%lld"
            ",\"major_faults\":%lld"
            ",\"voluntary_cs\":%lld"
            ",\"involuntary_cs\":%lld"
            ",\"exit_code\":%d"
            ",\"term_signal\":%d"
            ",\"status\":",
            sqlite3_column_double(s, 4),
            sqlite3_column_double(s, 5),
            sqlite3_column_double(s, 6),
            (long long)sqlite3_column_int64(s, 7),
            (long long)sqlite3_column_int64(s, 8),
            (long long)sqlite3_column_int64(s, 9),
            (long long)sqlite3_column_int64(s, 10),
            (long long)sqlite3_column_int64(s, 11),
            sqlite3_column_int(s, 12),
            sqlite3_column_int(s, 13));

        json_string(b, sqlite3_column_text(s, 14));

        sqlite3_str_appendall(b, ",\"stdout\":");
        json_string(b, sqlite3_column_text(s, 15));

        sqlite3_str_appendall(b, ",\"stderr\":");
        json_string(b, sqlite3_column_text(s, 16));

        sqlite3_str_appendchar(b, 1, '}');
    }

    sqlite3_finalize(s);
    sqlite3_str_appendall(b, "]}");
    return sqlite3_str_finish(b);
}

char *db_stats_json(sqlite3 *db)
{
    sqlite3_str *b = sqlite3_str_new(db);
    sqlite3_str_appendall(b, "{\"stats\":[");

    /* Per-command aggregate stats for completed runs only */
    const char *sql =
        "SELECT command,"
        "       COUNT(*)         AS runs,"
        "       MIN(wall_ms)     AS min_ms,"
        "       AVG(wall_ms)     AS avg_ms,"
        "       MAX(wall_ms)     AS max_ms,"
        "       AVG(user_ms+system_ms) AS avg_cpu_ms,"
        "       AVG(max_rss_kb)  AS avg_rss_kb,"
        "       SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END) AS ok"
        " FROM runs"
        " GROUP BY command"
        " ORDER BY runs DESC";

    sqlite3_stmt *s = NULL;
    if (sqlite3_prepare_v2(db, sql, -1, &s, NULL) != SQLITE_OK) {
        sqlite3_str_appendall(b, "]}");
        return sqlite3_str_finish(b);
    }

    int first = 1;
    while (sqlite3_step(s) == SQLITE_ROW) {
        if (!first) sqlite3_str_appendchar(b, 1, ',');
        first = 0;

        int    runs   = sqlite3_column_int(s, 1);
        double min_ms = sqlite3_column_double(s, 2);
        double avg_ms = sqlite3_column_double(s, 3);
        double max_ms = sqlite3_column_double(s, 4);
        double cpu_ms = sqlite3_column_double(s, 5);
        double rss_kb = sqlite3_column_double(s, 6);
        int    ok     = sqlite3_column_int(s, 7);

        sqlite3_str_appendall(b, "{\"command\":");
        json_string(b, sqlite3_column_text(s, 0));
        sqlite3_str_appendf(b,
            ",\"runs\":%d"
            ",\"ok\":%d"
            ",\"min_ms\":%.3f"
            ",\"avg_ms\":%.3f"
            ",\"max_ms\":%.3f"
            ",\"avg_cpu_ms\":%.3f"
            ",\"avg_rss_kb\":%.1f}",
            runs, ok, min_ms, avg_ms, max_ms, cpu_ms, rss_kb);
    }

    sqlite3_finalize(s);
    sqlite3_str_appendall(b, "]}");
    return sqlite3_str_finish(b);
}
