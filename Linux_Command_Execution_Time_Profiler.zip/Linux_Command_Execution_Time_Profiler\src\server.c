/*
 * server.c – main HTTP server and request router
 *
 * Architecture:
 *   - A single parent process binds to 127.0.0.1:PORT and accept()s connections.
 *   - Each accepted connection is handled in a forked child process so that a
 *     slow command never blocks the listening socket.
 *   - SIGCHLD is caught with SA_RESTART|SA_NOCLDSTOP to reap children without
 *     creating zombies.
 *
 * OS concepts demonstrated:
 *   fork(), socket(), bind(), listen(), accept(), sigaction(),
 *   SIGCHLD, SA_RESTART, waitpid(WNOHANG), setpgid(), kill(),
 *   /proc/<pid>/status reading
 */
#include "http.h"
#include "db.h"
#include "profiler.h"
#include "syscall_trace.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <errno.h>
#include <unistd.h>
#include <ctype.h>
#include <limits.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/wait.h>
#include <sys/stat.h>

/* -------------------------------------------------------------------------
 * Configuration
 * ------------------------------------------------------------------------- */
#define PORT_DEFAULT 8080
#define DB_PATH      "db/profiler.db"

/* -------------------------------------------------------------------------
 * SIGCHLD handler – reap all finished children without blocking
 * ------------------------------------------------------------------------- */
static void sigchld_reaper(int sig)
{
    (void)sig;
    int saved_errno = errno;
    while (waitpid(-1, NULL, WNOHANG) > 0) {}
    errno = saved_errno;
}

/* -------------------------------------------------------------------------
 * Minimal JSON field extractors
 * (only for the fixed set of fields this server ever parses)
 * ------------------------------------------------------------------------- */

/**
 * json_get_str – find "key":"value" in *body* and copy value into *out*.
 * Control characters (< 0x20) are rejected.
 * @return 0 on success, -1 if key not found or value is invalid.
 */
static int json_get_str(const char *body, const char *key,
                        char *out, size_t cap)
{
    char needle[256];
    snprintf(needle, sizeof(needle), "\"%s\"", key);
    const char *p = strstr(body, needle);
    if (!p) return -1;

    p = strchr(p, ':');
    if (!p) return -1;
    p++;
    while (isspace((unsigned char)*p)) p++;
    if (*p != '"') return -1;
    p++;

    size_t n = 0;
    while (*p && *p != '"' && n + 1 < cap) {
        if (*p == '\\' && p[1]) p++; /* skip escape prefix */
        if ((unsigned char)*p < 32) return -1;
        out[n++] = *p++;
    }
    if (*p != '"') return -1;
    out[n] = '\0';
    return 0;
}

/**
 * json_get_int – find "key":<integer> in *body*.
 * Returns *def* if the key is absent or cannot be parsed.
 */
static int json_get_int(const char *body, const char *key, int def)
{
    char needle[256];
    snprintf(needle, sizeof(needle), "\"%s\"", key);
    const char *p = strstr(body, needle);
    if (!p) return def;
    p = strchr(p, ':');
    if (!p) return def;
    return atoi(p + 1);
}

/* -------------------------------------------------------------------------
 * JSON escaping for in-place result serialisation
 * ------------------------------------------------------------------------- */

/**
 * json_escape – write a JSON-escaped version of *src* into *dst*,
 * producing at most *cap - 1* bytes plus a NUL terminator.
 */
static void json_escape(const char *src, char *dst, size_t cap)
{
    size_t j = 0;
    for (const unsigned char *p = (unsigned char *)src;
         *p && j + 8 < cap; p++)
    {
        if      (*p == '"')  { dst[j++] = '\\'; dst[j++] = '"'; }
        else if (*p == '\\') { dst[j++] = '\\'; dst[j++] = '\\'; }
        else if (*p == '\n') { dst[j++] = '\\'; dst[j++] = 'n'; }
        else if (*p == '\r') { dst[j++] = '\\'; dst[j++] = 'r'; }
        else if (*p == '\t') { dst[j++] = '\\'; dst[j++] = 't'; }
        else if (*p >= 32)   { dst[j++] = (char)*p; }
    }
    dst[j] = '\0';
}

/* -------------------------------------------------------------------------
 * Route handlers
 * ------------------------------------------------------------------------- */

/** GET /api/allowlist – return the list of runnable command names. */
static void route_allowlist(int fd)
{
    http_send_json(fd, 200,
        "{\"commands\":["
        "\"ls\",\"pwd\",\"echo\",\"cat\",\"head\",\"tail\","
        "\"wc\",\"sort\",\"uniq\",\"grep\",\"find\",\"sleep\","
        "\"gzip\",\"date\",\"whoami\",\"uname\","
        "\"df\",\"du\",\"uptime\",\"free\""
        "]}");
}

/** GET /api/history – return latest 100 runs from SQLite. */
static void route_history(int fd)
{
    sqlite3 *db = NULL;
    if (db_open(&db, DB_PATH)) {
        http_send_json(fd, 500, "{\"error\":\"database unavailable\"}");
        return;
    }
    char *j = db_history_json(db);
    if (j) {
        http_send_json(fd, 200, j);
        sqlite3_free(j);
    } else {
        http_send_json(fd, 500, "{\"error\":\"history query failed\"}");
    }
    sqlite3_close(db);
}

/** GET /api/stats – per-command aggregate statistics. */
static void route_stats(int fd)
{
    sqlite3 *db = NULL;
    if (db_open(&db, DB_PATH)) {
        http_send_json(fd, 500, "{\"error\":\"database unavailable\"}");
        return;
    }
    char *j = db_stats_json(db);
    if (j) {
        http_send_json(fd, 200, j);
        sqlite3_free(j);
    } else {
        http_send_json(fd, 500, "{\"error\":\"stats query failed\"}");
    }
    sqlite3_close(db);
}

/**
 * GET /api/monitor?pid=<N>
 * Read /proc/<pid>/status for a snapshot of the process state.
 * This is read-only and does not attach to or control the target process.
 */
static void route_monitor(int fd, const char *path)
{
    const char *q = strchr(path, '?');
    if (!q || strncmp(q + 1, "pid=", 4) != 0) {
        http_send_json(fd, 400,
                       "{\"error\":\"use /api/monitor?pid=PID\"}");
        return;
    }

    char *endp = NULL;
    long pid = strtol(q + 5, &endp, 10);
    if (pid <= 1 || pid > INT_MAX
        || !endp || (*endp && *endp != '&'))
    {
        http_send_json(fd, 400, "{\"error\":\"invalid PID\"}");
        return;
    }

    /* Read /proc/<pid>/status */
    char proc_path[128];
    snprintf(proc_path, sizeof(proc_path), "/proc/%ld/status", pid);
    FILE *f = fopen(proc_path, "r");
    if (!f) {
        http_send_json(fd, 404,
                       "{\"error\":\"PID not found or not readable\"}");
        return;
    }

    char name[128]   = "unknown";
    char state[64]   = "unknown";
    long vmrss   = -1, vmsize = -1;
    long threads = -1;
    char line[512];

    while (fgets(line, sizeof(line), f)) {
        sscanf(line, "Name:\t%127[^\n]",  name);
        sscanf(line, "State:\t%63[^\n]",  state);
        sscanf(line, "VmRSS:\t%ld",       &vmrss);
        sscanf(line, "VmSize:\t%ld",      &vmsize);
        sscanf(line, "Threads:\t%ld",     &threads);
    }
    fclose(f);

    /* Also try /proc/<pid>/stat for CPU counters */
    long utime = 0, stime = 0, cutime = 0, cstime = 0;
    char stat_path[128];
    snprintf(stat_path, sizeof(stat_path), "/proc/%ld/stat", pid);
    FILE *sf = fopen(stat_path, "r");
    if (sf) {
        /* Fields: pid comm state ppid pgroup … utime stime cutime cstime
         * The return value is intentionally discarded; partial reads are
         * handled gracefully since utime/stime default to 0. */
        int dummy_i; long dummy_l; char dummy_c; char comm[256];
        if (fscanf(sf, "%d %255s %c %d %d %d %d %d %lu %lu %lu %lu "
                       "%lu %lu %ld %ld",
                       &dummy_i, comm, &dummy_c,
                       &dummy_i, &dummy_i, &dummy_i, &dummy_i, &dummy_i,
                       (unsigned long*)&dummy_l, (unsigned long*)&dummy_l,
                       (unsigned long*)&dummy_l, (unsigned long*)&dummy_l,
                       (unsigned long*)&utime, (unsigned long*)&stime,
                       &cutime, &cstime) < 0) {
            /* Handled gracefully; utime/stime remain 0 on error */
        }
        fclose(sf);
    }

    char out[1024];
    snprintf(out, sizeof(out),
             "{"
             "\"pid\":%ld,"
             "\"name\":\"%s\","
             "\"state\":\"%s\","
             "\"vmrss_kb\":%ld,"
             "\"vmsize_kb\":%ld,"
             "\"threads\":%ld,"
             "\"utime_ticks\":%ld,"
             "\"stime_ticks\":%ld,"
             "\"mode\":\"read_only_snapshot\""
             "}",
             pid, name, state, vmrss, vmsize, threads,
             utime, stime);

    http_send_json(fd, 200, out);
}

/**
 * POST /api/run – execute a command and return profiling metrics.
 * Body: {"command":"echo","args":"hello","timeout_ms":5000}
 */
static void route_run(int fd, const char *body)
{
    char cmd[64]  = "";
    char args[2048] = "";

    if (json_get_str(body, "command", cmd, sizeof(cmd))
        || !command_is_allowed(cmd))
    {
        http_send_json(fd, 403,
                       "{\"error\":\"command is not on the allowlist\"}");
        return;
    }

    (void)json_get_str(body, "args", args, sizeof(args));
    int timeout = json_get_int(body, "timeout_ms", 5000);

    profile_result_t r;
    if (profiler_run(cmd, args, timeout, &r)) {
        http_send_json(fd, 400,
                       "{\"error\":\"invalid arguments or timeout;"
                       " timeout must be 100..60000 ms\"}");
        return;
    }

    /* Save to SQLite (best-effort; don't fail the response if this errors) */
    sqlite3 *db = NULL;
    if (db_open(&db, DB_PATH) == 0) {
        db_add_run(db, cmd, args,
                   r.wall_ms, r.user_ms, r.system_ms,
                   r.max_rss_kb, r.minor_faults, r.major_faults,
                   r.voluntary_cs, r.involuntary_cs,
                   r.exit_code, r.term_signal,
                   r.status, r.out, r.err);
        sqlite3_close(db);
    }

    /* Escape text fields and build JSON response */
    size_t esc_cap = 270000;
    char *eo = calloc(1, esc_cap);
    char *ee = calloc(1, esc_cap);
    char *resp = malloc(600000);
    if (!eo || !ee || !resp) {
        free(eo); free(ee); free(resp);
        profiler_result_free(&r);
        http_send_json(fd, 500, "{\"error\":\"out of memory\"}");
        return;
    }

    json_escape(r.out ? r.out : "", eo, esc_cap);
    json_escape(r.err ? r.err : "", ee, esc_cap);

    snprintf(resp, 600000,
             "{"
             "\"status\":\"%s\","
             "\"wall_ms\":%.3f,"
             "\"user_ms\":%.3f,"
             "\"system_ms\":%.3f,"
             "\"max_rss_kb\":%ld,"
             "\"minor_faults\":%ld,"
             "\"major_faults\":%ld,"
             "\"voluntary_cs\":%ld,"
             "\"involuntary_cs\":%ld,"
             "\"exit_code\":%d,"
             "\"term_signal\":%d,"
             "\"timed_out\":%s,"
             "\"stdout\":\"%s\","
             "\"stderr\":\"%s\""
             "}",
             r.status,
             r.wall_ms, r.user_ms, r.system_ms,
             r.max_rss_kb, r.minor_faults, r.major_faults,
             r.voluntary_cs, r.involuntary_cs,
             r.exit_code, r.term_signal,
             r.timed_out ? "true" : "false",
             eo, ee);

    http_send_json(fd, 200, resp);
    free(eo); free(ee); free(resp);
    profiler_result_free(&r);
}

/**
 * POST /api/trace – run a command under ptrace and return syscall statistics.
 * Body: {"command":"ls","args":"-la","timeout_ms":5000}
 */
static void route_trace(int fd, const char *body)
{
    char cmd[64]    = "";
    char args[2048] = "";

    if (json_get_str(body, "command", cmd, sizeof(cmd))
        || !command_is_allowed(cmd))
    {
        http_send_json(fd, 403,
                       "{\"error\":\"command is not on the allowlist\"}");
        return;
    }

    (void)json_get_str(body, "args", args, sizeof(args));
    int timeout = json_get_int(body, "timeout_ms", 5000);

    char trace_json[16384];
    if (syscall_trace_run(cmd, args, timeout,
                          trace_json, sizeof(trace_json)) != 0)
    {
        /* The error message is already in trace_json as a JSON object */
        http_send_json(fd, 400, trace_json);
        return;
    }

    http_send_json(fd, 200, trace_json);
}

/* -------------------------------------------------------------------------
 * Request dispatcher
 * ------------------------------------------------------------------------- */
static void handle_connection(int fd)
{
    http_request_t q;
    if (http_read_request(fd, &q)) {
        http_send_json(fd, 400, "{\"error\":\"malformed HTTP request\"}");
        return;
    }

    /* Static files */
    if (!strcmp(q.method, "GET") && !strcmp(q.path, "/")) {
        http_send_file(fd, "public/index.html"); return;
    }
    if (!strcmp(q.method, "GET") && !strcmp(q.path, "/style.css")) {
        http_send_file(fd, "public/style.css"); return;
    }
    if (!strcmp(q.method, "GET") && !strcmp(q.path, "/app.js")) {
        http_send_file(fd, "public/app.js"); return;
    }

    /* API routes */
    if (!strcmp(q.method, "GET")
        && !strcmp(q.path, "/api/allowlist"))
    {
        route_allowlist(fd); return;
    }
    if (!strcmp(q.method, "GET")
        && !strcmp(q.path, "/api/history"))
    {
        route_history(fd); return;
    }
    if (!strcmp(q.method, "GET")
        && !strcmp(q.path, "/api/stats"))
    {
        route_stats(fd); return;
    }
    if (!strcmp(q.method, "GET")
        && !strncmp(q.path, "/api/monitor", 12))
    {
        route_monitor(fd, q.path); return;
    }
    if (!strcmp(q.method, "POST")
        && !strcmp(q.path, "/api/run"))
    {
        route_run(fd, q.body); return;
    }
    if (!strcmp(q.method, "POST")
        && !strcmp(q.path, "/api/trace"))
    {
        route_trace(fd, q.body); return;
    }

    http_send_json(fd, 404, "{\"error\":\"not found\"}");
}

/* -------------------------------------------------------------------------
 * main
 * ------------------------------------------------------------------------- */
int main(int argc, char **argv)
{
    int port = PORT_DEFAULT;
    if (argc > 1) {
        port = atoi(argv[1]);
        if (port < 1024 || port > 65535) {
            fprintf(stderr, "Port must be in range 1024..65535\n");
            return 1;
        }
    }

    /* Ensure database directory exists */
    if (access("db", F_OK) != 0)
        mkdir("db", 0755);

    /* Initialise database (creates tables if needed) */
    sqlite3 *init_db = NULL;
    if (db_open(&init_db, DB_PATH)) {
        fprintf(stderr, "Cannot initialize database at %s\n", DB_PATH);
        return 1;
    }
    sqlite3_close(init_db);

    /* Install SIGCHLD handler to reap forked request children */
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = sigchld_reaper;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_RESTART | SA_NOCLDSTOP;
    sigaction(SIGCHLD, &sa, NULL);

    /* Create and bind listening socket (loopback only) */
    int srv = socket(AF_INET, SOCK_STREAM, 0);
    if (srv < 0) { perror("socket"); return 1; }

    int yes = 1;
    setsockopt(srv, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));

    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family      = AF_INET;
    addr.sin_port        = htons((unsigned short)port);
    addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK); /* 127.0.0.1 only */

    if (bind(srv, (struct sockaddr *)&addr, sizeof(addr))
        || listen(srv, 64))
    {
        perror("bind/listen");
        close(srv);
        return 1;
    }

    printf("Linux Command Execution Time Profiler\n");
    printf("Server: http://127.0.0.1:%d\n", port);
    printf("Press Ctrl+C to stop.\n\n");
    fflush(stdout);

    /* Accept loop – each connection handled in a child process */
    for (;;) {
        int conn = accept(srv, NULL, NULL);
        if (conn < 0) {
            if (errno == EINTR) continue;   /* SIGCHLD interrupted accept() */
            perror("accept");
            continue;
        }

        pid_t child = fork();
        if (child == 0) {
            /* ---- Child: handle one request then exit ---- */
            signal(SIGCHLD, SIG_DFL); /* restore default in child */
            close(srv);
            handle_connection(conn);
            close(conn);
            _exit(0);
        }

        /* Parent: close the accepted fd and loop */
        close(conn);
        if (child < 0) perror("fork");
    }

    /* Unreachable */
    close(srv);
    return 0;
}
